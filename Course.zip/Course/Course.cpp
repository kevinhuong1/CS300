#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <sstream>

using namespace std;



bool caseInsensitiveStringCompare(const std::string& str1, const std::string& str2)
{
    if (str1.size() != str2.size())
    {
        return false;
    }
    for (std::string::const_iterator c1 = str1.begin(), c2 = str2.begin();
        c1 != str1.end(); ++c1, ++c2)
    {
        if (tolower(static_cast <unsigned char>(*c1)) !=
            tolower(static_cast <unsigned char>(*c2)))
        {
            return false;
        }
    }
    return true;
}

void printCourseList(string filename)
{
    // create ifstream from the file
    ifstream file(filename.c_str(), fstream::in);
    // check if file is open
    if (!file.is_open())
    {
        cout << "File " << filename << " not found" << endl;
    }
    // will hold string from a line in file
    string line;
    // read each line in the file and print out
    while (getline(file, line))
    {
        // declare variables to hold course data
        string courseNo;
        string courseName;
        vector < string > prerequisite;
        // will hold string tokens from splitting line
        vector < string > result;
        //create string stream from the line
        std::stringstream s_stream(line);
        string substr;
        // get substring of line from string stream and push to stack
        while (std::getline(s_stream, substr, ','))
        {
            result.push_back(substr.c_str());
        }
        // extract the results into the course variables
        for (int i = 0; i < result.size(); i++)
        {
            if (i == 0)
                courseNo = result.at(i);
            if (i == 1)
                courseName = result.at(i);
            else
            {
                prerequisite.push_back(result.at(i));
            }
        }
        // print out course details
        cout << "\n" << courseNo << ", " << courseName << "\n";
        cout << "Prerequisites: ";
        for (int i = 0; i < prerequisite.size() - 1; i++)
            cout << prerequisite.at(i + 1) << " ";
        cout << "\n";
    }
    file.close();
}

void printCourse(string rse, string filename)
{
    // create ifstream from the file
    ifstream file(filename.c_str(), fstream::in);
    // check if file is open
    if (!file.is_open())
    {
        cout << "File " << filename << " not found" << endl;
    }
    // will hold string from a line in file
    string line;
    // checks if file was found
    int flag = 1;
    while (getline(file, line))
    {
        // declare variables to hold course data
        string courseNo;
        string courseName;
        vector < string > prerequisite;
        vector < string > result;
        //create string stream from the string
        stringstream s_stream(line);
        string substr;
        while (getline(s_stream, substr, ','))
        {
            result.push_back(substr.c_str());
        }
        for (int i = 0; i < result.size(); i++)
        {
            if (i == 0)
                courseNo = result.at(i);
            if (i == 1)
                courseName = result.at(i);
            else
            {
                prerequisite.push_back(result.at(i));
            }
        }
        // compare if is query course No
        if (caseInsensitiveStringCompare(rse, courseNo))
        {
            cout << "\n" << courseNo << ", " << courseName << "\n";
            cout << "Prerequisites: ";
            for (int i = 0; i < prerequisite.size() - 1; i++)
                cout << prerequisite.at(i + 1) << " ";
            cout << "\n";
            flag = 0;
        }
        break;
    }
    if (flag)
        cout << rse << " Not Found" << endl;
    file.close();
}

int  main()
{
    // filename
    string file = "courses.txt";

    while (true)
    {
        // menu
        cout << "\nWelcome to the course planner.\n" <<
            "1. Load Data Structure.\n" << "2. Print Course List.\n" <<
            "3. Print Course.\n" << "4. Exit\n" << "What would you like to do? ";
        int choice;
        cin >> choice;
        int flag = 0;
        string course;
        switch (choice)
        {
        case 1:
            cout << "Enter path to file: ";
            cin >> file;
            break;

        case 2:
            printCourseList(file);
            break;

        case 3:
            cout << "What course do you want to know about?";
            cin >> course;
            printCourse(course, file);
            break;

        case 4:
            cout << "Thank you for using the course planner!" << endl;
            flag = 1;
            break;

        default:
            cout << choice << " is not a valid option, try again (;" << endl;
            break;
        }
        if (flag)break;
    }
    return 0;
}
